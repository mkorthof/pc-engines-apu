#!/bin/sh

if [ -e /etc/modules ]; then
  if grep -q "leds-apu" /etc/modules; then
    sed -i ':a;N;$!ba;s/\nleds-apu//g' /etc/modules
  fi
fi

if [ -e /etc/rc.local ]; then
  if grep -q "/sys/class/leds/apu" /etc/rc.local; then
    sed -i -e '\@# PC Engines APU LEDs@d' \
           -e '\@# Example: echo disk-activity > \/sys\/class\/leds\/apu\\:2\/trigger@d' \
           -e '\@# - list options: cat \/sys\/class\/leds\/apu\\:1\/trigger@d' \
           -e '\@# - commented out: led1 (poweron)@d' \
           -e '\@if \[ -f \/sys\/class\/leds\/apu\\:2\/trigger \]; then echo .* > \/sys\/class\/leds\/apu\\:2\/trigger; fi@d' \
           -e '\@if \[ -f \/sys\/class\/leds\/apu\\:3\/trigger \]; then echo .* > \/sys\/class\/leds\/apu\\:3\/trigger; fi@d' /etc/rc.local 
    sed -i -e ':a;N;$!ba;s@\n#\n# if \[ -f \/sys\/class\/leds\/apu\\:1\/trigger \]; then echo 1 > \/sys\/class\/leds\/apu\\:1\/brightness; fi\n@@' /etc/rc.local
  fi
fi

