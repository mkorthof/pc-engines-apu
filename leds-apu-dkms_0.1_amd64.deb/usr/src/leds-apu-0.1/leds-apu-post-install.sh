#!/bin/sh

if [ -e /etc/modules ]; then
  if ! grep -q "leds-apu" /etc/modules; then
    echo "leds-apu" >> /etc/modules
  fi
fi

if [ -e /etc/rc.local ]; then
  if ! grep -q "/sys/class/leds/apu" /etc/rc.local; then
      awk '
      BEGIN { found = 0 }
      function instext(i) 
      {
        print "# PC Engines APU LEDs"
        print "# Example: echo disk-activity > /sys/class/leds/apu\:2/trigger"
        print "# - list options: cat /sys/class/leds/apu\:1/trigger"
        print "# - commented out: led1 (poweron)"
        print "#"
        print "# if [ -f /sys/class/leds/apu\:1/trigger ]; then echo 1 > /sys/class/leds/apu\:1/brightness; fi"
        print "if [ -f /sys/class/leds/apu\:2/trigger ]; then echo disk-activity > /sys/class/leds/apu\:2/trigger; fi"
        print "if [ -f /sys/class/leds/apu\:3/trigger ]; then echo cpu0 > /sys/class/leds/apu\:3/trigger; fi"
        print ""
        if (i == 1) print "exit 0"
      }
      /^exit 0$/ { found = 1; instext(0); }
      END { if (!found) instext(1) } 1' /etc/rc.local > /tmp/rc.local.$$ && \
      mv /tmp/rc.local.$$ /etc/rc.local && chmod 755 /etc/rc.local
  fi
fi
